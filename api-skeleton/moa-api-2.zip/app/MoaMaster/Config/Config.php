<?php

/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 3/21/18
 * Time: 4:43 PM
 */

namespace MoaMaster\Config;


class Config{

    public static $DSN = "sqlsrv:Server=MOASQL01,1433";
    public static $USERNAME = "sa";
    public static $PASSWORD = "m2a2oh58";

}
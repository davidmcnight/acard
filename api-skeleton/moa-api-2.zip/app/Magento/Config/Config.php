<?php

/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 2/28/18
 * Time: 4:29 PM
 */

namespace Magento\Config;

class Config{

    public static $magDSN = "mysql:host=db01.medalsofamerica.cl.zerolag.com;dbname=medals_db";
    public static  $magUser = "medals_db";
    public static  $magPassword = "tmiVNno10+vvxkrx";
    public static $token = "8d9tgncdmp7gjty3p90awpteqqxhgq8j";
    public static  $apiurl = 'https://www.medalsofamerica.com/rest/V1/';

}
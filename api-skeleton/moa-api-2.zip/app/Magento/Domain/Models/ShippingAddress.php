<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 5/7/18
 * Time: 3:57 PM
 */

namespace Magento\Domain\Models;


use MedalsObject\IRestModel;
use MedalsObject\Helpers\DataHelper;
class ShippingAddress implements IRestModel{

    private $order_id;
    private $first_name;
    private $last_name;
    private $email;
    private $phone;
    private $street_1;
    private $street_2;
    private $city;
    private $state;
    private $zip;
    private $country;


    public function setAttributes($parameters = array())
    {
        if(isset($parameters->entity_id)){
            $this->order_id = $parameters->entity_id;
        }

        if(isset($parameters->firstname)){
            $this->first_name = $parameters->firstname;
        }
        if(isset($parameters->lastname)){
            $this->last_name = $parameters->lastname;
        }

        if(isset($parameters->email)){
            $this->email = $parameters->email;
        }

        if(isset($parameters->telephone)){
            $this->phone = $parameters->telephone;
        }

        if(isset($parameters->street[0])){
            $this->street_1 = $parameters->street[0];
        }

        if(isset($parameters->street[1])){
            $this->street_2 = $parameters->street[1];
        }

        if(isset($parameters->city)){
            $this->city = $parameters->city;
        }

        if(isset($parameters->region_code)){
            $this->state = $parameters->region_code;
        }

        if(isset($parameters->postcode)){
            $this->zip = $parameters->postcode;
        }

        if(isset($parameters->country_id)){
            $this->country = $parameters->country_id;
        }
    }

    public function convertToDbObject(){
        $data = array(
            "first_name"=>$this->first_name,
            "last_name"=>$this->last_name,
            "email"=>$this->email,
            "phone"=>$this->phone,
            "street_1"=>$this->street_1,
            "street_2"=>$this->street_2,
            "city"=>$this->city,
            "state" => $this->state,
            "zip" => $this->zip,
            "country" => $this->country
        );
        return DataHelper::makeObject($data);
    }

    public function toJSONObject()
    {
        // TODO: Implement toJSONObject() method.
    }

    public function toString()
    {
        // TODO: Implement toString() method.
    }


}
<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 5/7/18
 * Time: 3:57 PM
 */

namespace Magento\Domain\Models;


use MedalsObject\IRestModel;
use MedalsObject\Helpers\DataHelper;

class BillingAddress implements IRestModel{


    private $order_id;
    private $first_name;
    private $last_name;
    private $email;
    private $phone;
    private $street_1;
    private $street_2;
    private $city;
    private $state;
    private $zip;
    private $country;

    /**
     * @param mixed $order_id
     */
    public function setOrderId($order_id){
        $this->order_id = $order_id;
    }


    public function setAttributes($parameters = array()){

        if(isset($parameters->entity_id)){
            $this->order_id = $parameters->entity_id;
        }

        if(isset($parameters->billing_address->firstname)){
            $this->first_name = $parameters->billing_address->firstname;
        }
        if(isset($parameters->billing_address->lastname)){
            $this->last_name = $parameters->billing_address->lastname;
        }

        if(isset($parameters->billing_address->email)){
            $this->email = $parameters->billing_address->email;
        }

        if(isset($parameters->billing_address->telephone)){
            $this->phone = $parameters->billing_address->telephone;
        }

        if(isset($parameters->billing_address->street[0])){
            $this->street_1 = $parameters->billing_address->street[0];
        }

        if(isset($parameters->billing_address->street[1])){
            $this->street_2 = $parameters->billing_address->street[1];
        }

        if(isset($parameters->billing_address->city)){
            $this->city = $parameters->billing_address->city;
        }

        if(isset($parameters->billing_address->region_code)){
            $this->state = $parameters->billing_address->region_code;
        }

        if(isset($parameters->billing_address->postcode)){
            $this->zip = $parameters->billing_address->postcode;
        }

        if(isset($parameters->billing_address->country_id)){
            $this->country = $parameters->billing_address->country_id;
        }



    }

    public function convertToDbObject(){
        $data = array(
            "first_name"=>$this->first_name,
            "last_name"=>$this->last_name,
            "email"=>$this->email,
            "phone"=>$this->phone,
            "street_1"=>$this->street_1,
            "street_2"=>$this->street_2,
            "city"=>$this->city,
            "state" => $this->state,
            "zip" => $this->zip,
            "country" => $this->country
        );
        return DataHelper::makeObject($data);
    }

    public function toJSONObject()
    {
        // TODO: Implement toJSONObject() method.
    }

    public function toString()
    {
        // TODO: Implement toString() method.
    }


}
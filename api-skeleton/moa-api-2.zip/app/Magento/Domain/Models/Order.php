<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 3/27/18
 * Time: 9:34 AM
 */

namespace Magento\Domain\Models;


use MedalsObject\Helpers\DataHelper;
use MedalsObject\IRestModel;

class Order implements IRestModel
{
    private $order_id;
    private $gross_amount; // total of line items -- excluding tax, shipping, discount
    private $net_amount; // total of line items including discount, excluding shipping, tax
    private $total_amount; // total of line times including discount, shipping, tax
    private $payment_method;
    private $shipping_amount;
    private $shipping_method;
    private $tax_amount;
    private $discount_amount;
    private $discount_code;
    private $status;
    private $state;
    private $status_id;
    private $customer_message;
    private $is_address; //on hold for now
    private $date_created;
    private $date_modified;

    private $created_at;
    private $updated_at;


    public function setAttributes($parameters = array()){
        if(isset($parameters->entity_id)){
            $this->order_id = $parameters->entity_id;
        }
        if(isset($parameters->base_subtotal)){
            $this->gross_amount = $parameters->base_subtotal;
        }

        $this->setDiscountAmount($parameters);
        $this->setNetAmount();
        $this->setTaxAmount($parameters);

        if(isset($parameters->shipping_amount)){
            $this->shipping_amount = $parameters->shipping_amount;
        }

        if(isset($parameters->base_total_due)){
            $this->total_amount = $parameters->base_total_due;
        }
        $this->setPaymentMethod($parameters);
        $this->setShippingMethod($parameters);

        if(isset($parameters->coupon_code)){
            $this->discount_code = $parameters->coupon_code;
        }

        if(isset($parameters->status)){
            $this->status = $parameters->status;
        }

        if(isset($parameters->state)){
            $this->state = $parameters->state;
        }

        if(isset($parameters->um_order_comment)){
            $this->customer_message = $parameters->um_order_comment;
        }

        if(isset($parameters->created_at)){
            $this->date_created = $parameters->created_at;
        }

        if(isset($parameters->updated_at)){
            $this->date_modified = $parameters->updated_at;
        }

        if(isset($parameters->remote_ip)){
            $this->is_address = $parameters->remote_ip;
        }


    }

    //this is used for the moa_master database
    public function convertToDbObject(){
        $data = array(
            "site_id" => "moa",
            "web_order_id"=>$this->order_id,
            "gross_amount"=>$this->gross_amount,
            "net_amount"=>$this->net_amount,
            "total_amount"=>$this->total_amount,
            "payment_method"=>$this->payment_method,
            "shipping_amount"=>$this->shipping_amount,
            "shipping_method"=>$this->shipping_method,
            "discount_amount"=>$this->discount_amount,
            "discount_code" => $this->discount_code,
            "tax_amount" => $this->tax_amount,
            "status" => $this->status,
            "is_processed" => 0,
            "customer_message"=>$this->customer_message,
            "date_created"=>$this->date_created,
            "date_modified"=>$this->date_modified
        );
        return DataHelper::makeObject($data);
    }

    public function toJSONObject()
    {
        // TODO: Implement toJSONObject() method.
    }


    public function toString()
    {
        // TODO: Implement toString() method.
    }

    /**
     * @param mixed $discount_amount
     */
    public function setDiscountAmount($parameters){
        if(isset($parameters->discount_amount)){
            $this->discount_amount = abs($parameters->discount_amount);
        }else{
            $this->discount_amount = 0.00;
        }
    }

    /**
     * @param mixed $tax_amount
     */

    public function setTaxAmount($parameters){
        if(isset($parameters->tax_amount)){
            $this->tax_amount = $parameters->tax_amount;
        }else{
            $this->tax_amount = 0.00;
        }

    }

    /**
     * @param mixed $net_amount
     */
    public function setNetAmount(){
        $this->net_amount = $this->gross_amount - $this->discount_amount;
    }

    /**
     * @param mixed $payment_method
     */
    public function setPaymentMethod($parameters){
        if(trim($parameters->payment->method) == "redstage_offlinecc"){
           $this->payment_method = "CC";
        }

        if(strtolower(trim($parameters->payment->method) == "paypal")){
            $this->payment_method = "PayPal";
        }

    }

    /**
     * @param mixed $shipping_method
     */
    public function setShippingMethod($parameters){

        if(trim($parameters->shipping_description) == "MOA - Standard Shipping  5-6 days") {
            $this->shipping_method = "standard";
        }
    }

    /**
     * @param mixed $status_id
     */
    public function setStatusId(){
        if($this->status ==  "processing"){

        }
    }













}
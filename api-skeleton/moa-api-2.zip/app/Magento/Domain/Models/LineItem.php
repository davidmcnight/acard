<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 5/29/18
 * Time: 2:59 PM
 */
namespace Magento\Domain\Models;
use MedalsObject\Helpers\DataHelper;
use MedalsObject\IRestModel;


class LineItem implements IRestModel{

    private $sku;
    private $product_id;
    private $line_tem_id;
    private $name;
    private $product_type;
    private $parent_item_id;
    private $price;
    private $quantity;
    private $base_price;
    private $tax_price;


    public function setAttributes($parameters = array()){
        if(isset($parameters["type"])){
            if($parameters["type"] == "builder_base"){
                $this->createBuilderBase($parameters["item"]);
            }
        }else{
         //reg?

        }
    }

    public function convertToDbObject(){
        if(isset($parameters["type"])) {
            if ($parameters["type"] == "builder_base") {
                return $this->convertBuilderBase();
            }
        }else{

        }
        return null;
    }

    public function toJSONObject()
    {
        // TODO: Implement toJSONObject() method.
    }

    public function toString(){
        // TODO: Implement toString() method.
    }


    //this is a static
    private function createBuilderBase($item){
        $this->name = $item->type;
        $this->sku = $item->type;
        $this->price = 0;
        $this->line_tem_id = $item->item_id;
        $this->quantity = $item->qty_ordered;
    }

    public function convertBuilderBase(){
        $data = array(
            "sku"=>$this->sku,
            "name"=>$this->name,
            "gross_amount"=> 0,
            "net_amount"=> 0,
            "total_amount"=> 0,
            "tax_amount"=> 0,
            "discount_amount"=> 0,
            "quantity" => $this->quantity
        );
        return DataHelper::makeObject($data);
    }


}
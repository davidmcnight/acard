<?php

/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 2/28/18
 * Time: 3:47 PM
 */
namespace Magento\Domain\Models;
use MedalsObject\IRestModel;
use MedalsObject\Helpers\DataHelper;

class Product implements IRestModel {

    private $sku;
    private $price;
    private $special_price;
    private $base_url;

    public function setAttributes($parameters = array()){
        // TODO: Implement setAttributes() method.
    }

    public function convertToDbObject()
    {
        // TODO: Implement convertToDbObject() method.
    }

    public function toJSONObject()
    {
        // TODO: Implement toJSONObject() method.
    }


    public function toString()
    {
        // TODO: Implement toString() method.
    }

    public function getProductUpdateJSON(){

    }







}
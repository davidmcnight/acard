<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 5/4/18
 * Time: 11:55 AM
 */

namespace Magento\Domain\Services;


use Magento\Config\Config;
use MedalsObject\IRestService;

class OrderService implements IRestService{


    public function get($id){
        $url = Config::$apiurl . "redstagesales/orders/" . $id;
        $order = $this->getCurl($url);
        return $order;
    }

    public function getAll()
    {
        // TODO: Implement getAll() method.
    }

    public function getChildren($id, $childClass)
    {
        // TODO: Implement getChildren() method.
    }

    public function getByForeignKey($fk, $foreignClass)
    {
        // TODO: Implement getByForeignKey() method.
    }

    public function find($parameters = array()){

    }

    public function post($data)
    {
        // TODO: Implement post() method.
    }

    public function put($data){
        // TODO: Implement put() method.
    }

    public function patch($data)
    {
        // TODO: Implement patch() method.
    }

    public function delete($id)
    {
        // TODO: Implement delete() method.
    }

    private function getCurl($url){
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "Authorization: Bearer " . Config::$token));
        return $data = json_decode(curl_exec($ch));
    }


}
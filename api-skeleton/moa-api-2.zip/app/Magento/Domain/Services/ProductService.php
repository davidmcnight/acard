<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 2/28/18
 * Time: 3:53 PM
 */

namespace Magento\Domain\Services;
use Magento\Config\Config;
use Magento\Domain\Factory\Factory;
use MedalsObject\IRestService;
use Magento\Config\Config as MagConfig;
use PHPMailer\PHPMailer\Exception;
use Magento\Helpers\QueryBuilder;

class ProductService implements IRestService{

    public function get($id){
        // TODO: Implement get() method.
    }

    public function getAll()
    {
        // TODO: Implement getAll() method.
    }

    public function getChildren($id, $childClass)
    {
        // TODO: Implement getChildren() method.
    }

    public function getByForeignKey($fk, $foreignClass){
        // TODO: Implement getByForeignKey() method.
    }

    public function find($parameters = array()){
        try{



            if(isset($parameters["getImage"])){
                if ($parameters["sku"]){
                    $sku = $parameters["sku"];
                    $username = "BDCqN8T6pHTfhWpRcgVyEwNJVHmr37";
                    $token = "2dTEQVDmJdfEq2ARt8BZhUoQkmb3GYfe4e";
                    $result = file_get_contents("https://medalsofamerica.com/moa-custom-scripts/test.php?username=" .
                        $username . "&&token=" . $token . "&getImage=1&sku=". $sku);
                    $result = json_decode($result);
                    return array("success"=>true,"sku"=>$result->sku, "image"=>$result->image);
                }else{
                    return array("success"=>false, "message"=>" There was no sku given. Please try again.");
                }
            } if(isset($parameters["doesProductExistDb"])){
                if ($parameters["sku"]){
                    $sku = $parameters["sku"];
                    $username = "BDCqN8T6pHTfhWpRcgVyEwNJVHmr37";
                    $token = "2dTEQVDmJdfEq2ARt8BZhUoQkmb3GYfe4e";
                    $result = file_get_contents("https://medalsofamerica.com/moa-custom-scripts/test.php?username=" .
                        $username . "&&token=" . $token . "&doesProductExist=1&sku=". $sku);
                    $result = json_decode($result);
                    if($result->exists == 1){
                        return true;
                    }
                    return false;
                }else{
                    return array("success"=>false, "message"=>" There was no sku given. Please try again.");
                }
            }else{
                return array("success"=>false, "message"=>"No correct parameters were specified.");
            }
        }catch (Exception $e){
            echo $e->getMessage();
        }
    }

    public function post($data)
    {
        // TODO: Implement post() method.
    }

    public function put($data){

        if(isset($data["simple_price_inventory_update"])){
           $this->createSimpleProductUpdate($data);
        }else if(isset($data["configurable_price_inventory_update"])){
            $this->createConfigurableProductUpdate($data);
        }else if(isset($data["child_price_inventory_update"])){
            $this->createChildProductUpdate($data);
        }else if(isset($data["updatePrice"])){
            $product = Factory::createModel("Product", $data["Product"]);
        }else if(isset($data["updateName"])){
            $this->updateProductName($data);
        }
        else{
            echo json_encode(array("success"=>false, "message" => "No correct parameters were specified"));
        }
    }

    public function patch($data)
    {
        // TODO: Implement patch() method.
    }

    public function delete($id)
    {
        // TODO: Implement delete() method.
    }

    private function updateProductName($data){
        $token = Config::$token;
        $url = "https://www.medalsofamerica.com/rest/V1/products/" . $data["product"]["sku"];

        $product_data = array(
            "product" => array(
                "name" => $data["product"]["name"],
            ));

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "Authorization: Bearer " . $token));
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($product_data));
        $result = curl_exec($ch);
        echo $result;
        exit;
    }

    private function createChildProductUpdate($data){
        $product = $data["child_data"];
        if($product["discontinued"] == 1) {

            $product_data = array(
                "product" => array(
                    "sku" => $product["sku"],
                    "visibility" => 1,
                    "extensionAttributes" => array(
                        "stockItem" => array(
                            "qty" => 0,
                        ),
                    ),
                )
            );


        }elseif ($product["closeout"] == 1 && $product["stock"]  < 1){
            $product_data = array(
                "product" => array(
                    "sku" => $product["sku"],
                    "visibility" => 1,
                    "extensionAttributes" => array(
                        "stockItem" => array(
                            "qty" => 0,
                        ),
                    ),
                )
            );

        echo "here";
        }   else{

            $product_data = array(
                "product" => array(
                    "sku" => $product["sku"],
                    "price" => $product["list_price"],
                    "extensionAttributes" => array(
                        "stockItem" => array(
                            "qty" => $product["stock"],
                        ),
                    ),
                    "custom_attributes" => array(
                        "special_price" => $product["sales_price"]
                    )
                )
            );

        }


        if ($product["in_stock"] == 1) {
            $product_data["product"]["extensionAttributes"]["stockItem"]["isInStock"] = true;
        }else{
            $product_data["product"]["extensionAttributes"]["stockItem"]["isInStock"] = false;
        }

        if ($product["manage_stock"] == 1) {
            $product_data["product"]["extensionAttributes"]["stockItem"]["manage_stock"] = true;
        } else {
            $product_data["product"]["extensionAttributes"]["stockItem"]["manage_stock"] = false;
        }


        if ($product["allow_back_orders"] == 1) {
            $product_data["product"]["extensionAttributes"]["stockItem"]["backorders"] = 2;
        } else {
            $product_data["product"]["extensionAttributes"]["stockItem"]["backorders"] = 0;
        }


        $token = Config::$token;

        $url = "https://www.medalsofamerica.com/rest/V1/products";
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "Authorization: Bearer " . $token));
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($product_data));

        $result = curl_exec($ch);
        echo $result;

    }

    private function createConfigurableProductUpdate($data){
        $configurable = $data["config_data"];

        if($configurable["discontinued"] == 0) {
//            printNicely($configurable);
//            exit;
            $product_data = array(
                "product" => array(
                    "sku" => $configurable["sku"],
                    "price" => $configurable["list_price"],
                    "extensionAttributes" => array(
                        "stockItem" => array(
                            "qty" => $configurable["stock"],
                        ),
                    ),
                    "custom_attributes" => array(
                        "special_price" => $configurable["price_code_1"]
                    )
                )
            );

            //always in stock
            $product_data["product"]["extensionAttributes"]["stockItem"]["isInStock"] = true;
            //never manage stock
            $product_data["product"]["extensionAttributes"]["stockItem"]["manage_stock"] = false;
            //no back orders
            $product_data["product"]["extensionAttributes"]["stockItem"]["backorders"] = 0;

            $token = Config::$token;
            $url = "https://www.medalsofamerica.com/rest/V1/products";
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "Authorization: Bearer " . $token));
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($product_data));

            $result = curl_exec($ch);
            echo $result;

        }else{
            //item is discontinued
        }

    }

    private function createSimpleProductUpdate($data){
        $product = $data["product"];

        if($product["discontinued"] == 1) {

            $product_data = array(
                "product" => array(
                    "sku" => $product["sku"],
                    "visibility" => 1,
                    "extensionAttributes" => array(
                        "stockItem" => array(
                            "qty" => 0,
                        ),
                    ),
                )
            );


        }elseif ($product["closeout"] == 1 && $product["stock"]  < 1){
            $product_data = array(
                "product" => array(
                    "sku" => $product["sku"],
                    "visibility" => 1,
                    "extensionAttributes" => array(
                        "stockItem" => array(
                            "qty" => 0,
                        ),
                    ),
                )
            );

            echo "here";
        }   else{

            $product_data = array(
                "product" => array(
                    "sku" => $product["sku"],
                    "price" => $product["list_price"],
                    "extensionAttributes" => array(
                        "stockItem" => array(
                            "qty" => $product["stock"],
                        ),
                    ),
                    "custom_attributes" => array(
                        "special_price" => $product["sales_price"]
                    )
                )
            );

        }


        if ($product["in_stock"] == 1) {
            $product_data["product"]["extensionAttributes"]["stockItem"]["isInStock"] = true;
        }else{
            $product_data["product"]["extensionAttributes"]["stockItem"]["isInStock"] = false;
        }

        if ($product["manage_stock"] == 1) {
            $product_data["product"]["extensionAttributes"]["stockItem"]["manage_stock"] = true;
        } else {
            $product_data["product"]["extensionAttributes"]["stockItem"]["manage_stock"] = false;
        }


        if ($product["in_stock"] == 1) {
            $product_data["product"]["extensionAttributes"]["stockItem"]["isInStock"] = true;
        }else{
            $product_data["product"]["extensionAttributes"]["stockItem"]["isInStock"] = false;
        }

        if ($product["manage_stock"] == 1) {
            $product_data["product"]["extensionAttributes"]["stockItem"]["manage_stock"] = true;
        } else {
            $product_data["product"]["extensionAttributes"]["stockItem"]["manage_stock"] = false;
        }


        if ($product["allow_back_orders"] == 1) {
            $product_data["product"]["extensionAttributes"]["stockItem"]["backorders"] = 2;
        } else {
            $product_data["product"]["extensionAttributes"]["stockItem"]["backorders"] = 0;
        }



        $token = Config::$token;

        $url = "https://www.medalsofamerica.com/rest/V1/products";
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "Authorization: Bearer " . $token));
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($product_data));

        $result = curl_exec($ch);
        echo $result;


//        if($product_data["back_ordered"] == 0){
//            $product_data["product"]["extensionAttributes"]["stockItem"]["backorders"] = 1;
//        }

//        printNicely($product_data);

    }

}

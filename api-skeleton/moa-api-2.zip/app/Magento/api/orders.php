<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 8/27/18
 * Time: 9:42 AM
 */


$app->get(
    '/api/v1/magento/order/errors',
    function () use ($app) {




    });
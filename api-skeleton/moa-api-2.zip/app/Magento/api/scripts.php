<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 3/27/18
 * Time: 9:38 AM
 */



$app->get(
    '/api/v1/magento/:className',
    function ($className) use ($app) {
        $service = Factory::createService($className);
        $results = $service->getAll();
        printNicely($results);
    });

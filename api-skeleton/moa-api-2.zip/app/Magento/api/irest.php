<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 2/28/18
 * Time: 4:43 PM
 */


use Magento\Domain\Factory\Factory;

$app->get(
    '/api/v1/magento/:className',
    function ($className) use ($app) {
        $service = Factory::createService($className);
        $results = $service->getAll();
        printNicely($results);
    });

$app->get(
    '/api/v1/magento/find/:className',
    function ($className) use ($app) {
        $parameters = $app->request->params();
        $service = Factory::createService($className);
        $results = $service->find($parameters);
        echo json_encode($results);
    });

$app->put(
    '/api/v1/magento/:className',
    function ($className) use ($app) {
        $data = json_decode($app->request->getBody(), true);
        $service = Factory::createService($className);
        $service->put($data);
});
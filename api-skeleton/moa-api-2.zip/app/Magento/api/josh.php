<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 6/1/18
 * Time: 3:49 PM
 */
use Magento\Config\Config;
$app->get(
    '/api/v1/magento/for-the-douche/:sku',
    function ($sku) use ($app) {

        $token = Config::$token;
        $url = "https://www.medalsofamerica.com/rest/V1/products/" . $sku;

        $product_data = array(
            "product" => array(
                "status" => 2,
                "extensionAttributes" => array(
                    "stockItem" => array(
                        "qty" => 0,
                    ),
                ),
            )
        );
        $product_data["product"]["extensionAttributes"]["stockItem"]["manage_stock"] = true;
        $product_data["product"]["extensionAttributes"]["stockItem"]["isInStock"] = false;
        $product_data["product"]["extensionAttributes"]["stockItem"]["backorders"] = 0;

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "Authorization: Bearer " . $token));
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($product_data));
        $result = curl_exec($ch);
        echo $result;

    }
);

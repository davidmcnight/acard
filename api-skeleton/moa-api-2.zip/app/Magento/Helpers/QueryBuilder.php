<?php

/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 2/28/18
 * Time: 3:55 PM
 */
namespace Magento\Helpers;

class QueryBuilder{

    public static function getBaseQuery(){
        return "SELECT  e.sku,
              v1.value AS 'name',
              v2.value AS 'url_key',
              t1.value AS 'short_description',
              t2.value AS 'description',
              d1.value AS 'price',
               v3.value as 'image'
            FROM catalog_product_entity e
              -- varchar (name, url-key)
              LEFT JOIN catalog_product_entity_varchar v1 ON e.row_id = v1.row_id
                 AND v1.attribute_id =
                     (SELECT attribute_id
                      FROM eav_attribute
                      WHERE attribute_code = 'name'
                            AND entity_type_id =
                                (SELECT entity_type_id
                                 FROM eav_entity_type
                                 WHERE entity_type_code = 'catalog_product'))
                          
              LEFT JOIN catalog_product_entity_varchar v2 ON e.row_id = v2.row_id
                 AND v2.attribute_id =
                     (SELECT attribute_id
                      FROM eav_attribute
                      WHERE attribute_code = 'url_key'
                            AND entity_type_id =
                                (SELECT entity_type_id
                                 FROM eav_entity_type
                                 WHERE entity_type_code = 'catalog_product'))
             LEFT JOIN catalog_product_entity_varchar v3 ON e.row_id = v3.row_id
                 AND v3.attribute_id =
                     (SELECT attribute_id
                      FROM eav_attribute
                      WHERE attribute_code = 'image'
                            AND entity_type_id =
                                (SELECT entity_type_id
                                 FROM eav_entity_type
                                 WHERE entity_type_code = 'catalog_product'))

                                 
              -- varchar (description, short description)
              LEFT JOIN catalog_product_entity_text t1 ON e.row_id = t1.row_id
                  AND t1.attribute_id =
                      (SELECT attribute_id
                       FROM eav_attribute
                       WHERE attribute_code = 'short_description'
                             AND entity_type_id =
                                 (SELECT entity_type_id
                                  FROM eav_entity_type
                                  WHERE entity_type_code = 'catalog_product'))
              -- description
              LEFT JOIN catalog_product_entity_text t2 ON e.row_id = t2.row_id
                    AND t2.attribute_id =
                        (SELECT attribute_id
                         FROM eav_attribute
                         WHERE attribute_code = 'description'
                               AND entity_type_id =
                                   (SELECT entity_type_id
                                    FROM eav_entity_type
                                    WHERE entity_type_code = 'catalog_product'))
             LEFT JOIN catalog_product_entity_decimal d1 ON e.row_id = d1.row_id
            AND d1.store_id = 0
            AND d1.attribute_id =
              (SELECT attribute_id
               FROM eav_attribute
               WHERE attribute_code = 'price'
                 AND entity_type_id =
                   (SELECT entity_type_id
                    FROM eav_entity_type
                    WHERE entity_type_code = 'catalog_product'))";
    }

}
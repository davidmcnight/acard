<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 5/30/18
 * Time: 1:48 PM
 */

namespace Magento\Helpers;
use MedalsObject\Helpers\DataHelper;

class ProductUtility{


    public static function is_builder($item){
        if(DataHelper::cleanData($item->name) == "build your ribbons rack"){
            return true;
        }
        return false;
    }


    public static function is_artifi($item){
        if($item->is_artifi == 1){
            return true;
        }
        return false;
    }

    public static function is_configurable($item){
        if(DataHelper::cleanData($item->product_type) == "configurable"){
            return true;
        }
        return false;
    }



}
<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 7/24/18
 * Time: 5:30 PM
 */

use Response\Domain\Models\POHead;

$app->get(
    '/api/v1/response/:className',
    function ($className) use ($app) {
        echo $className;

        $pohead = POHead::where("PO_NUMBER", '=', 39456)
            ->with("vendor")->get()->first();
        printNicely($pohead->vendor);
    });

<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 7/24/18
 * Time: 5:39 PM
 */

namespace Response\Domain\Models;


use Illuminate\Database\Eloquent\Model;
use MedalsObject\IRestModel;

class Vendor extends Model implements IRestModel{


    protected $table = "VENDOR";
    protected $connection = "resp";

    public function po_head(){
        return $this->belongsTo('Response\\Domain\\Models\\POHead', "VENDOR_ID", "VENDOR_ID");
    }



    public function setAttributes($parameters = array())
    {
        // TODO: Implement setAttributes() method.
    }

    public function convertToDbObject()
    {
        // TODO: Implement convertToDbObject() method.
    }

    public function toJSONObject()
    {
        // TODO: Implement toJSONObject() method.
    }

    public function toString()
    {
        // TODO: Implement toString() method.
    }


}
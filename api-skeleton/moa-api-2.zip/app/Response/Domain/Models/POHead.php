<?php

namespace Response\Domain\Models;
use Illuminate\Database\Eloquent\Model;
use MedalsObject\IRestModel;

/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 7/24/18
 * Time: 5:27 PM
 */
class POHead extends Model implements IRestModel{


    protected $table = "POHEAD";
    protected $connection = "resp";
    protected $primaryKey = 'RECNUM';

    public function vendor(){
        return $this->hasOne("Response\\Domain\\Models\\Vendor", "VENDOR_ID", "VENDOR_ID");
    }



    public function setAttributes($parameters = array()){
        // TODO: Implement setAttributes() method.
    }

    public function convertToDbObject()
    {
        // TODO: Implement convertToDbObject() method.
    }

    public function toJSONObject()
    {
        // TODO: Implement toJSONObject() method.
    }

    public function toString()
    {
        // TODO: Implement toString() method.
    }


}
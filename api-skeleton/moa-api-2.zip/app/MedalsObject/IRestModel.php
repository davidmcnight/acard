<?php

/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 2/23/18
 * Time: 9:14 AM
 */
namespace MedalsObject;

interface IRestModel{

    public function setAttributes($parameters = array());
    public function convertToDbObject();
    public function toJSONObject();
    public function toString();

}
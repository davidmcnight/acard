<?php

/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 3/2/18
 * Time: 2:40 PM
 */


namespace MedalsObject\Helpers;

class DataHelper
{
    public static function makeObject($data = array()){
        return json_decode(json_encode($data), FALSE);
    }

    public static function cleanData($data){
        return strtolower(trim($data));
    }

}
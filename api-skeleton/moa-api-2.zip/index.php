<?php
/**
 * Step 1: Require the Slim Framework
 *
 * If you are not using Composer, you need to require the
 * Slim Framework and register its PSR-0 autoloader.
 *
 * If you are using Composer, you can skip this step.
 */


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

function printNicely($value){
    print nl2br(print_r($value, true));
}

//phpinfo();

header('Access-Control-Allow-Origin: *');


//ini_set('memory_limit','1000M');

//foreach (glob("app/MoaMag/api/*.php") as $filename) {require_once $filename;}

require 'Slim/Slim.php';
//require_once "Config.php";
require_once "vendor/autoload.php";

\Slim\Slim::registerAutoloader();

//Config::init();



/**
 * Step 2: Instantiate a Slim application
 *
 * This example instantiates a Slim application using
 * its default settings. However, you will usually configure
 * your Slim application now by passing an associative array
 * of setting names and values into the application constructor.
 */
$app = new \Slim\Slim();


/**
 * Step 3: Define the Slim application routes
 *
 * Here we define several Slim application routes that respond
 * to appropriate HTTP request methods. In this example, the second
 * argument for `Slim::get`, `Slim::post`, `Slim::put`, `Slim::patch`, and `Slim::delete`
 * is an anonymous function.
 */


//SET CONDITIONS
\Slim\Route::setDefaultConditions(array(
    'class' => '[a-zA-Z]{3,}',
    'parent' => '[a-zA-Z]{3,}',
    'child' => '[a-zA-Z]{3,}',
    'foreignClass' => '[a-zA-Z]{3,}',
    'fk' => '[0-9]{0,10000}',
    'id' =>'[0-9]{0,10000}'
));


//Database connections
$settings = array(

    'default' => 'sqlsrv',
    'connections' => array(
        'resp' => array(
            'driver' => 'sqlsrv',
            'host' => 'MOASQL01',
            'database' => 'R4W_primary;ConnectionPooling=0;',
            'username' => 'sa',
            'password' => 'm2a2oh58',
            'collation' => 'utf8_general_ci',
            'prefix' => ''
        ),

        'pattern' => array(
            'driver' => 'sqlsrv',
            'host' => 'MOASQL01',
            'database' => 'NBMS',
            'username' => 'sa',
            'password' => 'm2a2oh58',
            'collation' => 'utf8_general_ci',
            'prefix' => ''
        )
    ,
        'moa_live' => array(
            'driver' => 'sqlsrv',
            'host' => 'MOASQL01',
            'database' => 'MOA_Master',
            'username' => 'sa',
            'password' => 'm2a2oh58',
            'collation' => 'utf8_general_ci',
            'prefix' => ''
        )
        ,
        'moa' => array(
            'driver' => 'sqlsrv',
            'host' => 'MOASQL01',
            'database' => 'MOA_MasterTest',
            'username' => 'sa',
            'password' => 'm2a2oh58',
            'collation' => 'utf8_general_ci',
            'prefix' => ''
        )
    )

);


//bootstrapping everything
$container = new Illuminate\Container\Container;
$connFactory = new \Illuminate\Database\Connectors\ConnectionFactory($container);
$resp = $connFactory->make($settings["connections"]["resp"]);
$resp1 = $connFactory->make($settings["connections"]["moa"]);
$resp2 = $connFactory->make($settings["connections"]["pattern"]);
$resolver = new \Illuminate\Database\ConnectionResolver();
$resolver->addConnection('resp', $resp);
$resolver->addConnection('moa', $resp1);
$resolver->addConnection('pattern', $resp2);
$resolver->setDefaultConnection('resp');
\Illuminate\Database\Eloquent\Model::setConnectionResolver($resolver);

//required files (API) Namespaces in composer JSON
foreach (glob("app/MoaMaster/api/*.php") as $filename) {require_once $filename;}
foreach (glob("app/PatriotIssue/api/*.php") as $filename) {require_once $filename;}
foreach (glob("app/Magento/api/*.php") as $filename) {require_once $filename;}
foreach (glob("app/Response/api/*.php") as $filename) {require_once $filename;}
foreach (glob("app/api/interfaces/*.php") as $filename) {require_once $filename;}
foreach (glob("app/api/integrations/*.php") as $filename) {require_once $filename;}

use Magento\Config\Config as MagConfig;
//test urls
$app->get(
    '/',
    function () use ($app) {
        try{

            $url = "https://www.medalsofamerica.com/rest/V1/products/build_your_medal_rack";
            $token = MagConfig::$token;
            $product_data = array(
                "product" => array(
                    "name" => "build_your_medal_rack",
                ));

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
            curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "Authorization: Bearer " . $token));
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($product_data));
            $result = curl_exec($ch);
            echo $result;
        }catch (Exception $e){
            echo $e->getMessage();
        }
    }
);


$app->get(
    '/ssh',
    function () use ($app) {
        $result = file_get_contents("https://medalsofamerica.com/moa-custom-scripts/test.php?username=BDCqN8T6pHTfhWpRcgVyEwNJVHmr37&&token=2dTEQVDmJdfEq2ARt8BZhUoQkmb3GYfe4e&getImage=1&sku=f005");
        printNicely($result);
    }
);


use Magento\Config\Config;

$app->get(
    '/email-test',
    function () use ($app) {

        $url = "https://www.medalsofamerica.com/rest/V1/orders/1110388/comments";
        $token = MagConfig::$token;
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "Authorization: Bearer " . $token));
        $order__data = array("statusHistory"=>
            array(
                "comment" =>"Your order is being fulfilled. We'll send a confirmation when your order ships.",
                "is_customer_notified" => 1,
                "is_visible_on_front" => 1,
                "status" => "awf",
                "extension_attributes" => array(
                   
                    )
                )
            );


        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($order__data));
        $result = curl_exec($ch);
        echo $result;
//
//
//        $ch = Helpers::getPOSTCurl($token, $url);
//        $data = array();
//        if($status == "processing"){
//            $data = array("statusHistory"
//            => array(
//                    "comment" =>"",
//                    "is_customer_notified" => 0,
//                    "is_visible_on_front" => 1,
//                    "status" => "processing"
//                )
//            );
//        }
//
//        if($status == "processed"){
//            $data = array("statusHistory"
//            => array(
//                    "comment" =>"Your order is has been processed. You will receive an update as soon as your order is finished.",
//                    "is_customer_notified" => 0,
//                    "is_visible_on_front" => 1,
//                    "status" => "processed"
//                )
//            );
//        }elseif($status == "holded"){
//            $data = array("statusHistory"
//            => array(
//                    "comment" =>"Your order has been placed on hold. We will update as soon as we can.",
//                    "is_customer_notified" => 0,
//                    "is_visible_on_front" => 1,
//                    "status" => "holded"
//                )
//            );
//        }elseif($status == "reviewed"){
//            $data = array("statusHistory"
//            => array(
//                    "comment" =>"Your order is being reviewed.",
//                    "is_customer_notified" => 0,
//                    "is_visible_on_front" => 1,
//                    "status" => "reviewed"
//                )
//            );
//        }elseif($status == "pending"){
//            $data = array("statusHistory"
//            => array(
//                    "comment" =>"Your order is being reviewed.",
//                    "is_customer_notified" => 0,
//                    "is_visible_on_front" => 1,
//                    "status" => "pending"
//                )
//            );
//        }
//
//        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
//

    }
);



// run app
$app->run();
